SST Windows Authentication Test Scripts - Version 8.0
=====================================================

Expected VM names
-----------------
SQL Server VM: DIR-VIRTUAL-SER
Client VM:     DIR-VIRTUAL-CLI

Defaults
--------
SQL instance: SST
TCP port:     52525
Password:     SST-Test-2026!

Both scripts prompt for the tester username and password. Press Enter at the
password prompt to accept SST-Test-2026!. Enter the same username and password
in both scripts.

Run order
---------
1. On DIR-VIRTUAL-SER, run Setup-SqlTestUser-Server-v8.ps1 as Administrator.
2. On DIR-VIRTUAL-CLI, while signed in with the work account, run Setup-SqlTestUser-Client-v8.ps1 as Administrator.
3. Enter the same tester username and password in both scripts.
4. Sign out of the client VM.
5. Sign in as .\<tester username> using the selected password.
6. Connect with Windows Authentication to tcp:DIR-VIRTUAL-SER,52525.

PowerShell execution commands
-----------------------------
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
Unblock-File ".\Setup-SqlTestUser-Server-v8.ps1"
.\Setup-SqlTestUser-Server-v8.ps1

or on the client:

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
Unblock-File ".\Setup-SqlTestUser-Client-v8.ps1"
.\Setup-SqlTestUser-Client-v8.ps1

Warning
-------
These scripts grant SQL sysadmin/local administrator access and use an easy
password by default. Use them only in disposable test VMs.
